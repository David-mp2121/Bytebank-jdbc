package br.com.alura.bytebank.domain.conta;

public class ContaDAO {



}
