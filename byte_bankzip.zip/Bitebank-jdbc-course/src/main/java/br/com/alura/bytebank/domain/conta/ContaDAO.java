package br.com.alura.bytebank.domain.conta;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import javax.management.RuntimeErrorException;

import br.com.alura.bytebank.domain.cliente.Cliente;
import br.com.alura.bytebank.domain.cliente.DadosCadastroCliente;

public class ContaDAO {

	private Connection conn;

	ContaDAO(Connection connection) {

		this.conn = connection;
	}

	public void salvar(DadosAberturaConta dadosDaConta) {
		var cliente = new Cliente(dadosDaConta.dadosCliente());
		var conta = new Conta(dadosDaConta.numero(), BigDecimal.ZERO, cliente);
		String sql = "INSERT INTO conta(numero, saldo, cliente_nome, cliente_cpf, cliente_email)"
				+ "VALUES (?, ?, ?, ?, ?)";
		try {
			PreparedStatement prepareStatement = conn.prepareStatement(sql);

			prepareStatement.setInt(1, conta.getNumero());
			prepareStatement.setBigDecimal(2, BigDecimal.ZERO);
			prepareStatement.setString(3, dadosDaConta.dadosCliente().nome());
			prepareStatement.setString(4, dadosDaConta.dadosCliente().cpf());
			prepareStatement.setString(5, dadosDaConta.dadosCliente().email());
			prepareStatement.execute();
			prepareStatement.close();
			conn.close();
		} catch (SQLException e) {

			throw new RuntimeException(e);
		}

	}

	public Set<Conta> listar() {
		Set<Conta> contas = new HashSet<>();

		String sql = "SELECT * FROM conta";
		PreparedStatement ps = null;
		ResultSet resultSet = null;

		try {
			ps = conn.prepareStatement(sql);
			System.out.println("abre connection");
			resultSet = ps.executeQuery();
			System.out.println("abre connection");

			while (resultSet.next()) {
				int numero = resultSet.getInt(1);
				BigDecimal saldo = resultSet.getBigDecimal(2);
				String nome = resultSet.getString(3);
				String cpf = resultSet.getString(4);
				String email = resultSet.getString(5);
				var dadosCadastraClientes = new DadosCadastroCliente(nome, cpf, email);
				var cliente = new Cliente(dadosCadastraClientes);
				contas.add(new Conta(numero, saldo, cliente));
			}
			ps.close();
			resultSet.close();
			conn.close();

		} catch (SQLException e) {
			throw new RuntimeException();
		} finally {

		}

		return contas;

	}

	public Conta listarPorNumero(int numero) {
		String sql = "SELECT * FROM conta WHERE numero = ?";
		Conta conta = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			System.out.println("abre connection");
			ps.setInt(1, numero);
			rs = ps.executeQuery();
			System.out.println("abre connection");

			while (rs.next()) {
				int numeroRecuperado = rs.getInt(1);
				BigDecimal saldo = rs.getBigDecimal(2);
				String nome = rs.getString(3);
				String cpf = rs.getString(4);
				String email = rs.getString(5);
				var dadosCadastroCliente = new DadosCadastroCliente(nome, cpf, email);
				var cliente = new Cliente(dadosCadastroCliente);
				conta = new Conta(numeroRecuperado, saldo, cliente);

			}
			rs.close();
			System.out.println("fecha connection");
			ps.close();
			System.out.println("fecha connection");
			conn.close();
			System.out.println("fecha connection");

		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

		return conta;
	}

	public void alterar(Integer numero, BigDecimal valor) {
		PreparedStatement ps;

		String sqlUpdate = "UPDATE conta SET saldo = ? WHERE numero = ?";
		try {
			conn.setAutoCommit(false);
			// set o saldo atualizado na conta em questão

			ps = conn.prepareStatement(sqlUpdate);
			System.out.println("abre connection");

			ps.setBigDecimal(1, valor);
			ps.setInt(2, numero);

			ps.execute();
			conn.commit();
			ps.close();
			conn.close();

		} catch (SQLException e) {
			try {
				conn.rollback();
			}catch(SQLException ex) {
				throw new RuntimeException(ex);
			}
			throw new RuntimeException(e);
		}

	}

}
